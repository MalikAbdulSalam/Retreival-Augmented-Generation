from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
import os
from dotenv import load_dotenv
from langchain_huggingface import HuggingFaceEmbeddings
from langchain_community.vectorstores import FAISS
from langchain_groq import ChatGroq

load_dotenv()

app = Flask(__name__)

# Enable CORS for universal embedding
CORS(app, resources={r"/*": {"origins": "*"}})

# Get absolute paths
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
VECTORSTORE_PATH = os.path.join(BASE_DIR, "vectorstore")

print(f"Looking for vectorstore at: {VECTORSTORE_PATH}")

# Check if vectorstore exists
if not os.path.exists(VECTORSTORE_PATH):
    print(f"❌ Error: Vectorstore not found at {VECTORSTORE_PATH}")
    print("Please run ingest.py first to create the vectorstore.")
    exit(1)

# Initialize components (same as before)
print("Loading embeddings...")
embeddings = HuggingFaceEmbeddings(
    model_name="sentence-transformers/all-MiniLM-L6-v2"
)

print("Loading vector database...")
db = FAISS.load_local(
    VECTORSTORE_PATH,
    embeddings,
    allow_dangerous_deserialization=True
)

print(f"✅ Vectorstore loaded successfully!")
print(f"📊 Contains {db.index.ntotal} vectors")

retriever = db.as_retriever(search_kwargs={"k": 3})

print("Initializing Groq LLM...")
llm = ChatGroq(
    api_key=os.getenv("GROQ_API_KEY"),
    model="llama-3.3-70b-versatile",
    temperature=0
)

print("✅ Backend ready!")

# Routes
@app.route('/api/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    return jsonify({"status": "healthy", "message": "Chatbot API is running"})

@app.route('/api/chat', methods=['POST'])
def chat():
    """Handle chat requests"""
    try:
        data = request.get_json()
        if not data or 'question' not in data:
            return jsonify({"error": "Missing question field"}), 400
        
        question = data['question']
        
        # Retrieve relevant documents
        docs = retriever.invoke(question)
        context = "\n\n".join(doc.page_content for doc in docs)
        
        # Create prompt
        prompt = f"""
You are an AI assistant.

Answer ONLY from the context below.

If the answer is not available in the context, reply exactly:

I don't know based on the provided document.

Context:
{context}

Question:
{question}

Answer:
"""
        
        # Get response from LLM
        response = llm.invoke(prompt)
        
        return jsonify({
            "answer": response.content,
            "sources": [doc.metadata.get("source", "Unknown") for doc in docs]
        })
    
    except Exception as e:
        print(f"Error: {e}")
        return jsonify({"error": str(e)}), 500

# Serve widget files (optional)
@app.route('/widget/<path:filename>')
def serve_widget(filename):
    """Serve the widget files"""
    widget_path = os.path.join(os.path.dirname(BASE_DIR), 'frontend')
    return send_from_directory(widget_path, filename)

@app.route('/widget')
def widget_index():
    """Serve the widget HTML page"""
    widget_path = os.path.join(os.path.dirname(BASE_DIR), 'frontend', 'widget.html')
    return send_from_directory(os.path.dirname(widget_path), 'widget.html')

if __name__ == '__main__':
    print("🚀 Starting Chatbot API Server with Flask...")
    print(f"📍 API available at: http://localhost:8000")
    print(f"📍 Health check: http://localhost:8000/api/health")
    print(f"📍 Chat endpoint: http://localhost:8000/api/chat")
    print(f"📍 Widget available at: http://localhost:8000/widget")
    print("\nPress Ctrl+C to stop the server")
    
    app.run(
        host='0.0.0.0',
        port=8000,
        debug=True  # Auto-reload on code changes
    )
