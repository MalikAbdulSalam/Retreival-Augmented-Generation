class ChatbotWidget {
    constructor(config = {}) {
        this.config = {
            apiUrl: config.apiUrl || 'http://localhost:8000',
            position: config.position || 'bottom-right',
            primaryColor: config.primaryColor || '#4F46E5',
            secondaryColor: config.secondaryColor || '#ffffff',
            botName: config.botName || 'AI Assistant',
            welcomeMessage: config.welcomeMessage || 'Hello! How can I help you today?',
            ...config
        };
        
        this.messages = [];
        this.isOpen = false;
        this.init();
    }
    
    init() {
        this.createWidget();
        this.createStyles();
        this.setupEventListeners();
        this.addWelcomeMessage();
    }
    
    createStyles() {
        const style = document.createElement('style');
        style.textContent = `
            .chatbot-widget {
                position: fixed;
                ${this.config.position === 'bottom-right' ? 'bottom: 20px; right: 20px;' : 'bottom: 20px; left: 20px;'}
                z-index: 999999;
                font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, sans-serif;
            }
            
            .chatbot-toggle {
                width: 60px;
                height: 60px;
                border-radius: 50%;
                background: ${this.config.primaryColor};
                color: ${this.config.secondaryColor};
                border: none;
                cursor: pointer;
                box-shadow: 0 4px 12px rgba(0,0,0,0.15);
                transition: all 0.3s ease;
                display: flex;
                align-items: center;
                justify-content: center;
                font-size: 28px;
            }
            
            .chatbot-toggle:hover {
                transform: scale(1.05);
                box-shadow: 0 6px 20px rgba(0,0,0,0.2);
            }
            
            .chatbot-window {
                position: absolute;
                bottom: 80px;
                ${this.config.position === 'bottom-right' ? 'right: 0;' : 'left: 0;'}
                width: 380px;
                height: 500px;
                background: white;
                border-radius: 16px;
                box-shadow: 0 10px 40px rgba(0,0,0,0.15);
                display: none;
                flex-direction: column;
                overflow: hidden;
                animation: slideIn 0.3s ease;
            }
            
            .chatbot-window.open {
                display: flex;
            }
            
            .chatbot-header {
                background: ${this.config.primaryColor};
                color: ${this.config.secondaryColor};
                padding: 16px 20px;
                display: flex;
                justify-content: space-between;
                align-items: center;
                border-bottom: 1px solid rgba(255,255,255,0.1);
            }
            
            .chatbot-header-title {
                font-weight: 600;
                font-size: 16px;
                display: flex;
                align-items: center;
                gap: 10px;
            }
            
            .chatbot-close {
                background: none;
                border: none;
                color: ${this.config.secondaryColor};
                cursor: pointer;
                font-size: 20px;
                padding: 4px 8px;
                border-radius: 4px;
                opacity: 0.8;
                transition: opacity 0.2s;
            }
            
            .chatbot-close:hover {
                opacity: 1;
            }
            
            .chatbot-messages {
                flex: 1;
                overflow-y: auto;
                padding: 16px 20px;
                background: #f8f9fa;
            }
            
            .message {
                margin-bottom: 12px;
                display: flex;
                flex-direction: column;
            }
            
            .message.user {
                align-items: flex-end;
            }
            
            .message.bot {
                align-items: flex-start;
            }
            
            .message-content {
                max-width: 80%;
                padding: 10px 14px;
                border-radius: 12px;
                word-wrap: break-word;
                line-height: 1.5;
                font-size: 14px;
            }
            
            .message.user .message-content {
                background: ${this.config.primaryColor};
                color: ${this.config.secondaryColor};
                border-bottom-right-radius: 4px;
            }
            
            .message.bot .message-content {
                background: white;
                color: #1a1a1a;
                border: 1px solid #e5e7eb;
                border-bottom-left-radius: 4px;
            }
            
            .message-timestamp {
                font-size: 11px;
                color: #6b7280;
                margin-top: 4px;
                padding: 0 4px;
            }
            
            .chatbot-input-container {
                padding: 16px 20px;
                background: white;
                border-top: 1px solid #e5e7eb;
                display: flex;
                gap: 10px;
            }
            
            .chatbot-input {
                flex: 1;
                padding: 10px 14px;
                border: 1px solid #d1d5db;
                border-radius: 8px;
                outline: none;
                font-size: 14px;
                transition: border-color 0.2s;
            }
            
            .chatbot-input:focus {
                border-color: ${this.config.primaryColor};
                box-shadow: 0 0 0 3px ${this.config.primaryColor}33;
            }
            
            .chatbot-send {
                padding: 10px 20px;
                background: ${this.config.primaryColor};
                color: ${this.config.secondaryColor};
                border: none;
                border-radius: 8px;
                cursor: pointer;
                font-weight: 500;
                transition: all 0.2s;
            }
            
            .chatbot-send:hover {
                opacity: 0.9;
                transform: translateY(-1px);
            }
            
            .chatbot-send:disabled {
                opacity: 0.5;
                cursor: not-allowed;
                transform: none;
            }
            
            .typing-indicator {
                display: flex;
                gap: 4px;
                padding: 8px 0;
            }
            
            .typing-indicator span {
                width: 8px;
                height: 8px;
                background: #9ca3af;
                border-radius: 50%;
                animation: bounce 1.4s infinite;
            }
            
            .typing-indicator span:nth-child(2) {
                animation-delay: 0.2s;
            }
            
            .typing-indicator span:nth-child(3) {
                animation-delay: 0.4s;
            }
            
            @keyframes bounce {
                0%, 60%, 100% { transform: translateY(0); }
                30% { transform: translateY(-10px); }
            }
            
            @keyframes slideIn {
                from {
                    opacity: 0;
                    transform: translateY(10px);
                }
                to {
                    opacity: 1;
                    transform: translateY(0);
                }
            }
            
            .chatbot-error {
                color: #ef4444;
                font-size: 13px;
                padding: 8px 12px;
                background: #fee2e2;
                border-radius: 6px;
                margin: 8px 0;
            }
            
            @media (max-width: 480px) {
                .chatbot-window {
                    width: 90vw;
                    height: 70vh;
                    bottom: 70px;
                }
            }
        `;
        document.head.appendChild(style);
    }
    
    createWidget() {
        const widget = document.createElement('div');
        widget.className = 'chatbot-widget';
        widget.id = 'chatbot-widget';
        
        widget.innerHTML = `
            <button class="chatbot-toggle" id="chatbot-toggle" aria-label="Toggle chat">
                💬
            </button>
            <div class="chatbot-window" id="chatbot-window">
                <div class="chatbot-header">
                    <div class="chatbot-header-title">
                        <span>🤖</span>
                        ${this.config.botName}
                    </div>
                    <button class="chatbot-close" id="chatbot-close">✕</button>
                </div>
                <div class="chatbot-messages" id="chatbot-messages"></div>
                <div class="chatbot-input-container">
                    <input type="text" class="chatbot-input" id="chatbot-input" placeholder="Type your message...">
                    <button class="chatbot-send" id="chatbot-send">Send</button>
                </div>
            </div>
        `;
        
        document.body.appendChild(widget);
    }
    
    setupEventListeners() {
        const toggleBtn = document.getElementById('chatbot-toggle');
        const closeBtn = document.getElementById('chatbot-close');
        const windowEl = document.getElementById('chatbot-window');
        const input = document.getElementById('chatbot-input');
        const sendBtn = document.getElementById('chatbot-send');
        
        toggleBtn.addEventListener('click', () => this.toggle());
        closeBtn.addEventListener('click', () => this.toggle());
        
        input.addEventListener('keypress', (e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                this.sendMessage();
            }
        });
        
        sendBtn.addEventListener('click', () => this.sendMessage());
        
        // Close on escape
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape' && this.isOpen) {
                this.toggle();
            }
        });
    }
    
    toggle() {
        this.isOpen = !this.isOpen;
        const windowEl = document.getElementById('chatbot-window');
        const toggleBtn = document.getElementById('chatbot-toggle');
        
        windowEl.classList.toggle('open');
        toggleBtn.textContent = this.isOpen ? '✕' : '💬';
        
        if (this.isOpen) {
            document.getElementById('chatbot-input').focus();
        }
    }
    
    addWelcomeMessage() {
        if (this.config.welcomeMessage) {
            setTimeout(() => {
                this.addMessage(this.config.welcomeMessage, 'bot');
            }, 500);
        }
    }
    
    addMessage(content, type, timestamp = new Date()) {
        const messagesContainer = document.getElementById('chatbot-messages');
        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${type}`;
        
        const timeStr = timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        
        messageDiv.innerHTML = `
            <div class="message-content">${content}</div>
            <div class="message-timestamp">${timeStr}</div>
        `;
        
        messagesContainer.appendChild(messageDiv);
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
        
        this.messages.push({ content, type, timestamp });
    }
    
    showTypingIndicator() {
        const messagesContainer = document.getElementById('chatbot-messages');
        const indicator = document.createElement('div');
        indicator.className = 'message bot';
        indicator.id = 'typing-indicator';
        indicator.innerHTML = `
            <div class="message-content">
                <div class="typing-indicator">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
            </div>
        `;
        messagesContainer.appendChild(indicator);
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
    }
    
    removeTypingIndicator() {
        const indicator = document.getElementById('typing-indicator');
        if (indicator) {
            indicator.remove();
        }
    }
    
    async sendMessage() {
        const input = document.getElementById('chatbot-input');
        const sendBtn = document.getElementById('chatbot-send');
        const message = input.value.trim();
        
        if (!message) return;
        
        input.value = '';
        sendBtn.disabled = true;
        
        this.addMessage(message, 'user');
        this.showTypingIndicator();
        
        try {
            const response = await fetch(`${this.config.apiUrl}/api/chat`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ question: message })
            });
            
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            
            const data = await response.json();
            this.removeTypingIndicator();
            
            let answer = data.answer;
            if (data.sources && data.sources.length > 0) {
                answer += '\n\n📚 Sources: ' + data.sources.join(', ');
            }
            
            this.addMessage(answer, 'bot');
        } catch (error) {
            this.removeTypingIndicator();
            this.addMessage(
                'Sorry, I encountered an error. Please try again later.',
                'bot'
            );
            console.error('Chat error:', error);
        } finally {
            sendBtn.disabled = false;
            input.focus();
        }
    }
}

// Initialize widget when loaded
if (typeof window !== 'undefined') {
    window.ChatbotWidget = ChatbotWidget;
}
